document.getElementById("app").innerText = "Value bets will appear here soon!";
